{
    "user": {},
    "settings": {},
    "hierarchy": {},
    "messages": {}
}
